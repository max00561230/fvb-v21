FVB Phase 1B approved restoration export.
Restoration tool version: v22.1-photo-restoration
Exported at: 2026-07-29T01:37:41.984Z
Page ID: page-002
Visible page number: 89
Source page filename: page-02.png
The flattened preview is generated client-side from the original page master at a bounded preview size. The JSON files keep full original-pixel and normalized placement, crop, rotation, and scale data for final processing.
This package does not replace public reader pages or modify original source scans.